"""Example of PyQtDarkTheme use for Qt applications.

To check example app, run:

```shell
python -m qdarktheme.widget_gallery
```
"""
