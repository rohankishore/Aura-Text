"""Package including ui for WidgetGallery."""
